let BASE_URL = 'http://sangtacviet.app';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}